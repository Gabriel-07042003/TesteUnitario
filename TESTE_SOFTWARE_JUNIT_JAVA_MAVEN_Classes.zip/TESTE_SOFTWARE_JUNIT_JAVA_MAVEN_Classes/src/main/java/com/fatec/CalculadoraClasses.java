package com.fatec;

import javax.swing.JOptionPane;

public class CalculadoraClasses {

	
	 public boolean isNumeroImpar(int numero) {
	        // Utiliza o operador módulo (%) para verificar se o resto da divisão do número por 2 é igual é  
		 // diferente de zero. Devolve true se for ímpar, false se for par.
	        return numero % 2 != 0;
	    }
	 
	 
	 public boolean isNumeroPrimo(int numero) {
	   if(numero>1 && numero>=2 ) {
	   return numero==2  || numero %2 !=0;
	   }
	   return false;
	 }
	
}
