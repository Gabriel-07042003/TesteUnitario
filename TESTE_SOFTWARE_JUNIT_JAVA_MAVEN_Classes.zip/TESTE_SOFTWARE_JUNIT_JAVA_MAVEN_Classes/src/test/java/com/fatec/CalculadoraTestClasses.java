package com.fatec;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class CalculadoraTestClasses {
	 CalculadoraClasses calc = new CalculadoraClasses();
	@ParameterizedTest(name = "Verificando se {0} é Impar")
	@ValueSource(ints = {1, 3, 5, 7, 101})
	void testNumerosImpares(int numero) {
        // Invoca o método de negócio e exige que a resposta seja estritamente 'true'. Se o método isNumeroImpar retornar 'false', o teste falha imediatamente.
        assertTrue(calc.isNumeroImpar(numero));
    }
	//Teste com uma maior finalidade de prospeção de erros
	@ParameterizedTest(name = "Verificando se {0} é Impar")
	@ValueSource(ints = {2, 4, 5, 1, 7})
	void testnaoNumerosImpares(int numero) {
        // Invoca o método de negócio e exige que a resposta seja estritamente 'true'. Se o método isNumeroImPar retornar 'false', o teste falha imediatamente.
        assertTrue(calc.isNumeroImpar(numero));
    }
	
	@ParameterizedTest(name = "Verificando se {0} é Primo")
	@ValueSource(ints = {1, 2, 5, 7, 101})
	void testNumerosPrimos(int numero) {
        // Invoca o método de negócio e exige que a resposta seja estritamente 'true'. Se o método isNumeroPrimo retornar 'false', o teste falha imediatamente.
        assertTrue(calc.isNumeroPrimo(numero));
    }
}
